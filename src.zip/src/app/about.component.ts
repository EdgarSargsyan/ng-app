import { Component} from '@angular/core';
  
@Component({
    selector: 'about-page',
  templateUrl: './about.component.html',
})
export class AboutComponent { }