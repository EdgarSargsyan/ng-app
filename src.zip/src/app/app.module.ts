import { NgModule, ErrorHandler } from '@angular/core';
import { FormsModule }      from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule, Http } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { RouterModule, Routes } from '@angular/router';
 
import { AppComponent }   from './app.component';
import { AboutComponent }   from './about.component';
import { HomeComponent }   from './home.component';
import { NotFoundComponent }   from './not-found.component';
 
import { ItemComponent }   from './item.component';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

const appRoutes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'currency/:id',      component: ItemComponent },
  { path: 'about', component: AboutComponent },
  { path: '**', component: NotFoundComponent }
];
 
@NgModule({
    imports:      [ BrowserModule, FormsModule, HttpModule,HttpClientModule, RouterModule.forRoot( appRoutes, { enableTracing: true } ), 
    TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: HttpLoaderFactory,
                deps: [HttpClient]
            }
        })],
    declarations: [ 
                    AppComponent, HomeComponent, 
                    AboutComponent, NotFoundComponent, 
                    ItemComponent
                ],
    providers: [ AppComponent ],
    bootstrap:    [ AppComponent ]
})
export class AppModule { }